# EKTBLY

HTML (Base level PHP is used to create componenets)

Need XAMPP or WAMPP to run the markup, caopy the project file inside the htdocs directory
