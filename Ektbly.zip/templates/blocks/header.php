<header>
   <div class="container">
      <div class="left">
         <a href="javascript:void(0)" class="icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="30" height="12" viewBox="0 0 30 12">
                <g id="Group_25742" data-name="Group 25742" transform="translate(-50.5 -32.5)">
                    <line id="Line_3268" data-name="Line 3268" x2="30" transform="translate(50.5 33.5)" fill="none" stroke="#000" stroke-width="2"/>
                    <line id="Line_3269" data-name="Line 3269" x2="30" transform="translate(50.5 43.5)" fill="none" stroke="#000" stroke-width="2"/>
                </g>
            </svg>
         </a>
         <a href="javascript:void(0)" class="icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="18" height="23" viewBox="0 0 18 23">
               <path id="Path_25365" data-name="Path 25365" d="M12,0A9,9,0,0,0,3,9V19H8a4,4,0,0,0,8,0h5V9A9,9,0,0,0,12,0Zm0,21a2,2,0,0,1-2-2h4A2,2,0,0,1,12,21Zm7-4H5V9A7,7,0,0,1,19,9Z" transform="translate(-3)" fill="#000"/>
            </svg>
         </a>
         <a href="javascript:void(0)" class="icon">
            <svg xmlns="http://www.w3.org/2000/svg" width="22.982" height="22.982" viewBox="0 0 22.982 22.982">
               <path id="Path_23856" data-name="Path 23856" d="M22.982,52.568l-5.241-5.241a10,10,0,1,0-1.414,1.415l5.241,5.24ZM2,41a8,8,0,1,1,8,8A8.009,8.009,0,0,1,2,41Z" transform="translate(0 -31)" fill="#000"/>
            </svg>
         </a>
         <ul>
            <li>
                <a href="#">Teachers</a>
            </li>
            <li>
                <a href="#">Students</a>
            </li>
         </ul>
      </div>
      <a href="javascript:void(0)">
         <svg xmlns="http://www.w3.org/2000/svg" width="133" height="24.99" viewBox="0 0 133 24.99">
            <path id="Path_25366" data-name="Path 25366" d="M-133.07,0h17.36V-2.8h-14.035v-8.645h12.985v-2.8h-12.985V-22.19h13.93v-2.8H-133.07Zm23.135,0h3.325V-8.75l4.165-3.885L-93.415,0h4.2L-100.17-14.91l10.535-10.08H-93.94l-12.67,12.46V-24.99h-3.325ZM-79.17,0h3.325V-22.19h8.33v-2.8H-87.5v2.8h8.33Zm19.5-11.445h7.6c2.8,0,5.425.91,5.425,4.165,0,2.73-1.82,4.48-4.69,4.48h-8.33ZM-63,0h12.075c4.97,0,7.6-3.5,7.6-7.175a5.726,5.726,0,0,0-4.76-6.02v-.07a5.773,5.773,0,0,0,3.71-5.6,5.931,5.931,0,0,0-2.94-5.215c-1.505-.91-4.41-.91-6.615-.91H-63Zm3.325-22.19h6.65c2.87,0,5.32.49,5.32,3.955,0,2.625-1.54,3.99-5.32,3.99h-6.65ZM-37.275,0H-20.72V-2.8H-33.95V-24.99h-3.325ZM-.07-24.99H-3.85l-7.315,11.9-7.49-11.9H-22.61l9.66,14.77V0h3.325V-10.22Z" transform="translate(133.07 24.99)" fill="#000"/>
         </svg>
      </a>
   </div>
</header>