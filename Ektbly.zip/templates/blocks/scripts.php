<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.6.3/jquery.min.js"></script>
<script src="static/js/swiper.min.js"></script>
<script src="static/js/global.js"></script>