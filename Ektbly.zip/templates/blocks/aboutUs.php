<section class="about">
    <div class="container">
        <div class="grid">
            <div class="image">
                <div class="inner">                    
                    <img src="static/img/04.jpg" alt="">
                </div>
            </div>
            <div class="text">
                <div class="top">
                    <p>About us</p>
                    <h3>Who we are?</h3>
                </div>
                <div class="bottom">
                    <p>Most of its text is made up from sections 1.10.32–3 of Cicero's De finibus bonorum et malorum (On the Boundaries of Goods and Evils; finibus may also be translated as purposes). Neque porro quisquam est qui dolorem ipsum quia dolor sit amet, consectetur, adipisci velit is the first known version ("Neither is there anyone who loves grief itself since it is grief and thus wants to obtain it"). It was found by Richard McClintock, a philologist, director of publications at Hampden-Sydney College in Virginia</p>
                </div>
            </div>
        </div>
    </div>
</section>