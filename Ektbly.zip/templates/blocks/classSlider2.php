<section class="classSlider">
    <div class="container">
        <div class="top">
            <h3>Upcoming Classes</h3>
            <button class="js-toggle-reserve">Reserve a slot</button>
        </div>  
        <div class="swiper-container swiper2">
            <div class="swiper-wrapper">
                <div class="swiper-slide slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/01.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>24/07/20 9.30am</p>
                            <p>How to structure narrative in fictio… English, Sarah Swan</p>
                        </a>
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/02.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>24/07/20 9.30am</p>
                            <p>How to structure narrative in fictio… English, Sarah Swan</p>
                        </a>
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/03.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>24/07/20 9.30am</p>
                            <p>How to structure narrative in fictio… English, Sarah Swan</p>
                        </a>
                    </div>
                </div>
                <div class="swiper-slide slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/01.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>24/07/20 9.30am</p>
                            <p>How to structure narrative in fictio… English, Sarah Swan</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>  
    </div>  
</section>