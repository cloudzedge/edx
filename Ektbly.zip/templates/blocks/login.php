<section class="login">
    <div class="image">
        <img src="static/img/09.jpg" alt="">
    </div>
    <div class="form">
        <form action="">
            <h1>Sign in</h1>
            <div class="formGroup">
                <label>Email</label>
                <input type="email">
            </div>
            <div class="formGroup">
                <label>Password</label>
                <input type="password">
            </div>
            <div class="formGroup">
                <input type="submit" value="Sign Up">
            </div>
            <div class="notebx">
                <p class="note">Not a member? <a href="register.php">Sign up</a></p>
                <p class="note"><a href="register.php">Forgot password?</a></p>
            </div>
        </form>
    </div>
</section>