<section class="tutorSlider">
    <div class="container">
        <div class="top">
            <h3>Book a Class With a Tutor</h3>
            <a href="#">See all</a>
        </div>  
        <div class="swiper-container swiper2">
            <div class="swiper-wrapper">
                <div class="swiper-slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/05.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>Olivia Preston <br>Biology, Chemistry, English +more</p>
                        </a>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/06.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>Olivia Preston <br>Science, Languages</p>
                        </a>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/07.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>Olivia Preston <br>Biology, Chemistry, English +more</p>
                        </a>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/08.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>Olivia Preston <br>Business Studies, PE, Maths</p>
                        </a>
                    </div>
                </div>
                <div class="swiper-slide">
                    <div class="image">
                        <a href="#">
                            <img src="static/img/07.jpg" alt="">
                        </a>
                    </div>
                    <div class="text">
                        <a href="#">
                            <p>Olivia Preston <br>Biology, Chemistry, English +more</p>
                        </a>
                    </div>
                </div>
            </div>
        </div>  
    </div>  
</section>