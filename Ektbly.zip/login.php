<!DOCTYPE html>
<html lang="en">
    <head>
        <?php include('templates/blocks/meta.php'); ?>
    </head>
    <body>
        <?php include('templates/blocks/header.php'); ?>

        <?php include('templates/blocks/login.php'); ?>

        <?php include('templates/blocks/footer.php'); ?>

        <?php include('templates/blocks/scripts.php'); ?>
    </body>
</html>